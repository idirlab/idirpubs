import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
import pickle
df = pd.read_csv("year_party_text.csv")
years = [1960, 1976, 1980, 1984, 1988, 1992, 1996, 2000, 2004, 2008, 2012]
parties = ['DEMOCRAT', 'REPUBLICAN']

data = pd.DataFrame(columns=years)
for party in parties:
	L = []
	for year in years:
		cfs = df.loc[(df.verdict == 1) & (df.year == year) & (df.party == party)]
		cv = CountVectorizer(stop_words="english", ngram_range=(2,2))
		counts = cv.fit_transform(cfs.text).toarray().sum(axis=0)
		indices = counts.argsort().tolist()[::-1]
		grams = sorted(list(cv.vocabulary_.keys()))
		two_gram = [(grams[i],counts[i]) for i in indices]
		L += ["\n".join([x[0] for x in two_gram[:20]])]
	data.loc[party] = L
	
data.to_csv('year_party_grams.csv', index='True', encoding='utf-8')
