#!/usr/bin/env python
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np

import util

def plot_coverage_error(data, save_base):
  plt.figure(figsize=(3.8, 4))
  for method, label, markerstyle, in (
      ('r', 'Beam-Rdm', 'ro-'), ('o', 'Beam-Opt', 'g*-'),
      ('c', 'Beam-Conv', 'bs-'), ('b', 'Breath-First', 'k^-')):
    ylst = []
    for entity in data[method]:
      rank_raw = data[method][entity]
      ranks = np.reshape(rank_raw, (len(rank_raw)//10, 10))
      avg_ranks = np.average(ranks, axis=0)
      y = [np.average(avg_ranks[:i]) for i in range(1, 11)]
      ylst.append(y)
    ylst = np.array(ylst)
    y = np.average(ylst, axis=0)
    x = list(range(1, len(y)+1))
    plt.plot(x, y, markerstyle, label=label)
  plt.gca().xaxis.set_major_locator(
      ticker.MaxNLocator(integer=True, nbins='auto'))
  #plt.legend(loc=(0.18, 0.14)).draggable()
  plt.legend(bbox_to_anchor=(-0.20, 0.94), loc="lower left",
                columnspacing=0.2, ncol=2, fontsize=16,
                frameon=False).draggable()
  plt.xlabel('Output size (k)')
  plt.ylabel('Average coverage error (Cov)', fontsize=18)
  plt.yscale('log')
  plt.tight_layout()
  plt.subplots_adjust(bottom=0.16, top=0.83)
  plt.savefig('%s.eps' % save_base)
  plt.show()

def make_plots():
  score = util.get_arg_or_default(1, 't')
  graph = util.get_arg_or_default(2, 'fifa')
  filename = 'data/effectiveness/%s/%s/top-10.rank.txt' % (graph, score)
  data = {}
  with open(filename) as file:
    for line in file:
      p, e, s, r = line.split()
      util.add_to_list_of_nested_dict(data, p, int(e), int(r))
  for p in data:
    for e in data[p]:
      data[p][e].sort()

  plot_coverage_error(data, '../eps/exp/coverage-error-%s-%s' % (graph, score))

if __name__ == '__main__':
  make_plots()
