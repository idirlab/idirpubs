#!/usr/bin/env python
import collections
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np

import util

def plot_fig(data, chi, nruns, eps_file):
  bins = np.arange(0, 1.1, 0.1)
  plot_conf = (('r', 'Beam-Rdm'), ('o', 'Beam-Opt'),
               ('c', 'Beam-Conv'), ('b', 'Breath-First'))
  nruns = dict(zip(('b', 'c', 'o', 'r'), map(int, nruns.split('-'))))
  fig, axs = plt.subplots(nrows=4, ncols=1, sharex=True, figsize=(4, 4))
  for row, (key, label) in enumerate(plot_conf):
    subfig = axs[row]
    dist = get_average_bin_counts(np.array(data[key]), bins, 1./nruns[key])
    cnts, _, _ = subfig.hist(dist, bins=bins, normed=False, rwidth=0.75,
                             fill=False, ec='b', lw=3)
    pos_y = 0.75
    pos_x = 1 if key != 'b' else 4
    subfig.text(bins[pos_x]*1.1, max(cnts)*pos_y, label, fontsize=20)
    subfig.set_ylim(0, max(cnts)*1.15)
    subfig.yaxis.set_major_locator(
        ticker.MaxNLocator(integer=True, nbins='auto'))
    #subfig.spines["top"].set_visible(False)
    #subfig.spines["right"].set_visible(False)

  axs[-1].set_xlabel(r'Exceptionality $\chi_%s$' % chi)
  fig.tight_layout()
  fig.text(0.01, 0.8, '#context-subspace pairs', fontsize=20,
           rotation='vertical')
  fig.subplots_adjust(left=0.21, bottom=0.17, hspace=0.20)
  plt.savefig(eps_file)
  plt.show()

def get_average_bin_counts(data, bins, ratio):
  cnts, _ = np.histogram(data, bins)
  averaged = []
  for i in range(1, len(bins)):
    left = data[data >= bins[i-1]]
    val = left[left < bins[i]]
    averaged.extend(val[:int(round(cnts[i-1] * ratio))])
  return averaged

def find_text_start_pos(cnts, threshold):
  indices = cnts >= (max(cnts) * threshold)
  best_pos = try_mid_and_left(indices)
  if best_pos == -1:
    best_pos = find_max_span(indices)
  return best_pos

def try_mid_and_left(indices):
  mid = len(indices) // 2
  step = 3
  starting = list(range(mid-1, len(indices)-3)) + list(range(0, mid))
  for i in starting:
    if np.all(indices[i: i+step]):
      return i
  return -1

def find_max_span(indices):
  positions = {}
  start = 0
  max_pos, max_len = 0, 0
  for idx, val in enumerate(indices):
    if val:
      start = idx + 1
    else:
      positions[start] = positions.get(start, 0) + 1
      if positions[start] > max_len:
        max_pos = start
        max_len = positions[start]
  return max_pos

def make_plot():
  graph = util.get_arg_or_default(1, 'worldcup')
  score = util.get_arg_or_default(2, 't')
  nruns = util.get_arg_or_default(3, '1-1-1-5')
  file_prefix = util.get_arg_or_default(
      4, 'data/effectiveness/%s/%s/{0}'% (graph, score))
  eps_file = '../eps/exp/effective-dist-%s-%s.eps' % (graph, score)
  data_filename = file_prefix.format('top-10.dist.txt')
  data = collections.defaultdict(list)
  with open(data_filename) as data_file:
    for line in data_file:
      p, chi = line.split()
      data[p].append(float(chi))
  chi = {'t': 'o', 'f': 'f'}[score]
  plot_fig(data, chi, nruns, eps_file)

if __name__ == '__main__':
  make_plot()
