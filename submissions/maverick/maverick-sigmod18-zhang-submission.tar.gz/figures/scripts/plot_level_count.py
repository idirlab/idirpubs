#!/usr/bin/env python
import collections
import glob

import matplotlib.pyplot as plt
import numpy as np

import util

def plot_level_count(data, save_to):
  bars = []
  max_levels = 0
  for idx, label, hatch, in (
      ('r', 'Beam-Rdm', '/'), ('o', 'Beam-Opt', 'o'),
      ('c', 'Beam-Conv', '.'), ('b', 'Breath-First', '*')):
    level_counts = [np.mean(cnts) for _, cnts in sorted(data[idx].items())]
    max_levels = max(max_levels, len(level_counts))
    bars.append((level_counts, label, hatch, idx))
  bar_width = 0.75
  index = np.arange(max_levels)
  fig, axs = plt.subplots(nrows=4, ncols=1, sharex=True, figsize=(3, 4.8))
  for row, (y, label, hatch, idx) in enumerate(bars):
    subfig = axs[row]
    subfig.bar(index[:len(y)], y, bar_width, label=label, fill=False,
               edgecolor='b', linewidth=2)
    if idx == 'b':
      subfig.set_yscale('log')
      subfig.set_ylim(0, 1000)
    else:
      subfig.set_ylim(0, 11)
    subfig.set_title(label)

  axs[-1].set_xlabel('Level ($|E_P|$)')
  fig.tight_layout()
  fig.text(0.01, 0.8, '#patterns evaluated', fontsize=20, rotation='vertical')
  fig.subplots_adjust(left=0.22, right=0.95, bottom=0.14, hspace=0.60)
  plt.savefig('%s.eps' % save_to)
  plt.show()

def plot_context_size(data, save_to):
  fig, axs = plt.subplots(nrows=4, ncols=1, sharex=True, figsize=(3, 4.8))
  row = 0
  for idx, label, _, in (
      ('r', 'Beam-Rdm', 'r*'), ('o', 'Beam-Opt', 'go'),
      ('c', 'Beam-Conv', 'k^'), ('b', 'Breath-First', 'bs')):
    counts = []
    for sizes in data[idx].values():
      for size, count in sizes.items():
        counts.extend([size] * round(count))
    subfig = axs[row]
    row += 1
    subfig.hist(counts, bins=10, normed=False, color='c', rwidth=0.75,
                fill=False, ec='b', lw=2)
    subfig.set_title(label)
    if idx == 'b':
      subfig.set_yscale('log')
      subfig.set_ylim(0, 1000)
  axs[-1].set_xlabel('Context size ($|C|$)')
  fig.tight_layout()
  fig.text(0.01, 0.8, '#patterns evaluated', fontsize=20, rotation='vertical')
  fig.subplots_adjust(left=0.22, right=0.95, bottom=0.15, hspace=0.60)
  plt.savefig('%s.eps' % save_to)
  plt.show()

def load_data(graph, score, entity, rounds):
  data = {'level': {}, 'size': {}}
  rounds = dict(zip(('b', 'c', 'o', 'r'), map(int, rounds.split('-'))))
  fn_pattern = 'data/iteration/%s/%s/%s/level-{0}.txt' % (graph, score, entity)
  for method in ('b', 'c', 'o', 'r'):
    fname = fn_pattern.format(method)
    data['level'][method] = collections.defaultdict(int)
    data['size'][method] = collections.defaultdict(collections.Counter)
    with open(fname) as data_file:
      for line in data_file:
        values = [int(x) for x in line.split()]
        data['level'][method][values[0]] += 1./rounds[method]
        data['size'][method][values[0]].update(values[1:])
    # Use average counts.
    for level in data['size'][method]:
      counter = data['size'][method][level]
      for size in counter:
        counter[size] /= 1. * rounds[method]
  return data

def make_plot():
  entity = util.get_arg_or_default(1, '46683')
  score = util.get_arg_or_default(2, 't')
  graph = util.get_arg_or_default(3, 'fifa')
  rounds = util.get_arg_or_default(4, '1-1-1-5')

  data = load_data(graph, score, entity, rounds)
  plot_level_count(data['level'],
                   '../eps/exp/level-count-%s-%s-%s' % (graph, score, entity))
  plot_context_size(data['size'],
                   '../eps/exp/context-size-%s-%s-%s' % (graph, score, entity))

if __name__ == '__main__':
  make_plot()
