#!/usr/bin/env python
import matplotlib.pyplot as plt
import numpy as np
import util

def make_plots():
  data_file = util.get_arg_or_default(1, 'data/prune.txt')
  data = np.loadtxt(data_file, dtype=int)
  meta = (('RelevantOnly+VarOnly', 'ro-'), ('RelevantOnly', 'bs-'),
          ('VarOnly', 'g^-'), ('None', 'kd-'))
  plt.figure(figsize=(4, 3.6))
  lines = []
  for i, (label, linestyle) in enumerate(meta):
    line = plt.plot(data[:, i], linestyle, fillstyle='none', label=label)
    lines.append(line)
  plt.ylabel('#patterns visited')
  plt.xlabel('Level ($|E_P|$)')
  plt.semilogy()
  #plt.legend(loc=(0.005, 0.43), frameon=False).draggable()
  ul_legend = plt.legend([l[0] for l in lines[:2]],
                         ['RelevantOnly+VarOnly', 'RelevantOnly'],
                         frameon=False, loc=(0.005, 0.73), fontsize=15)
  br_legend = plt.legend([l[0] for l in lines[2:]],
                         ['VarOnly', 'None'],
                         frameon=False, loc=(0.52, 0.005), fontsize=16)
  plt.gca().add_artist(ul_legend)
  plt.tight_layout()
  plt.savefig('../eps/exp/prune.eps')
  plt.show()


if __name__ == '__main__':
  make_plots()
