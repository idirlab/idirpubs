#!/usr/bin/env python
import copy
import matplotlib.colors as mcolors
import matplotlib.pyplot as plt
import numpy as np

import util

def plot_time_score(time_length, data, save_base):
  fig, axs = plt.subplots(nrows=2, ncols=2)
  cmap = copy.copy(plt.get_cmap('viridis'))
  cmap.set_bad('w')
  ranges = ((0, time_length), (0, 1.0000001))
  ims = []
  vmin, vmax = None, None
  for method, label, (row, col), in (
      ('b', 'Breath-First', (1, 1)), ('o', 'Beam-Opt', (0, 1)),
      ('c', 'Beam-Conv', (1, 0)), ('r', 'Beam-Rdm', (0, 0))):
    subfig = axs[row, col]
    counts, _, _, img = subfig.hist2d(data[method][:, 1], data[method][:, 0],
                                      bins=15, range=ranges, cmap=cmap, cmin=1,
                                      vmin=vmin, vmax=vmax,
                                      norm=mcolors.LogNorm())
    if method == 'b':
      vmin, vmax = np.nanmin(counts), np.nanmax(counts)
    ims.append(img)
    subfig.set_title(label)
    subfig.set_xlabel('Timestamp (sec.)')
    subfig.set_ylabel('$\\chi_o$')
    subfig.set_ylim(0, 1.05)
    #subfig.set_ylabel('Exceptionality $\\chi_o$')
  fig.tight_layout()
  fig.subplots_adjust(left=0.13, right=1.02, bottom=0.14, top=0.93, hspace=0.70)
  fig.colorbar(ims[-1], ax=axs.ravel().tolist(), pad=0.02)
  plt.savefig('%s.eps' % save_base)
  plt.show()

def load_data(file_prefix):
  data = {}
  for method in ('r', 'c', 'o', 'b'):
    data[method] = np.loadtxt('%s/%s.txt' % (file_prefix, method))
  return data

def make_plots():
  graph = util.get_arg_or_default(1, 'fifa')
  score = util.get_arg_or_default(2, 't')
  time_length = int(util.get_arg_or_default(3, 120))
  file_prefix = util.get_arg_or_default(
      4, 'data/time-score-heatmap/%s/%s' % (graph, score))
  data = load_data(file_prefix)
  plot_time_score(time_length, data, '../eps/exp/%s-time-score' % graph)

if __name__ == '__main__':
  make_plots()
