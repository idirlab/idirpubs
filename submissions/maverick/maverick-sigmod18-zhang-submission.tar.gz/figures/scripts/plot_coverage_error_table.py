import numpy as np

import util

def plot_table(data, take_median):
  beams = set(beam for entity in data for beam in data[entity])
  ylst = []
  for beam in sorted(beams):
    entity_ranks = []
    for entity in data:
      ranks = []
      for method in ('r', 'o', 'c', 'b'):
        if beam < 10 and method == 'b':
          beam_data = data[entity][10][method]
        else:
          beam_data = data[entity][beam][method]
        ranks.append(np.average(beam_data[:, 0]))
      entity_ranks.append(ranks)
    if take_median == 0:
      ylst.append(np.average(entity_ranks, axis=0))
    else:
      ylst.append(np.median(entity_ranks, axis=0))
  print(' \\\\ \\hline\n'.join(map(lambda a: ' & '.join(map(lambda x: ('%.1f' % x).center(15), a)), ylst)))
  print(sorted(beams))


def load_data(data_file):
  data = {}
  with open(data_file) as dfile:
    for line in dfile:
      method, beam, entity, score, rank = line.split()
      beam, entity, rank = map(int, (beam, entity, rank))
      if entity not in data:
        data[entity] = {}
      if beam not in data[entity]:
        data[entity][beam] = {'b':[], 'c':[], 'o':[], 'r':[]}
      data[entity][beam][method].append((rank, float(score)))
    for entity in data:
      for beam in data[entity]:
        for method in data[entity][beam]:
          data[entity][beam][method] = np.array(data[entity][beam][method])
  return data

def make_table():
  take_median = int(util.get_arg_or_default(1, 0))
  data_file = util.get_arg_or_default(
      2, 'data/effectiveness/fifa/t/top-10-b.rank.txt')
  all_entity_data = load_data(data_file)
  plot_table(all_entity_data, take_median)


if __name__ == '__main__':
  make_table()