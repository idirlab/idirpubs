#!/usr/bin/env python
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np
import util

def plot_fig(score, variable, xlabel, series, save_to):
  styles = {'r': 'ro-', 'c': 'bs-.', 'o': 'g*:', 'b': 'k^-.'}
  labels = {'r': 'Beam-Rdm', 'c': 'Beam-Conv', 'o': 'Beam-Opt',
            'b': 'Breath-First'}

  fig = plt.figure(figsize=(4, 4))
  subfig = fig.add_subplot(111)
  for p in ('r', 'o', 'c', 'b'):
    if p not in series or 10 not in series[p]:
      continue
    data = series[p][10]
    x = sorted(data.keys())
    y = [np.mean(data[xi]) for xi in x]
    #if p == 'r':
    z = np.polyfit(x, y, 3)
    func = np.poly1d(z)
    x = np.linspace(x[0], x[-1], len(x))
    y = func(x)
    subfig.plot(x, y, styles[p], label=labels[p], markersize=15)
  subfig.semilogy()

  subfig.set_ylabel('#patterns evaluated')
  subfig.set_xlabel(xlabel)
  subfig.xaxis.set_major_locator(
      ticker.MaxNLocator(integer=True, nbins='auto'))

  subfig.legend(bbox_to_anchor=(-0.20, 0.93), loc="lower left",
                columnspacing=0.2, ncol=2, fontsize=18,
                frameon=False).draggable()
  fig.tight_layout(pad=1.01)
  fig.subplots_adjust(left=0.20, right=0.97, bottom=0.14, top=0.83)
  plt.savefig('%s-%s-%s.eps' % (save_to, variable, score))
  plt.show()

def make_plots():
  graph = util.get_arg_or_default(1, 'fifa')
  score = util.get_arg_or_default(2, 't')
  entity = util.get_arg_or_default(3, '46683')
  data_filename = 'data/iteration/%s/%s/%s/num_pattern_total.txt' % (
      graph, score, entity)
  save_base = '../eps/exp/iter-%s-%s-%s' % (graph, score, entity)
  kseries, wseries = {}, {}
  with open(data_filename) as data_file:
    for line in data_file:
      cols = line.split()
      k, w, n = map(int, cols[1:])
      p = cols[0]
      util.add_to_list_of_nested_dict(kseries, p, w, k, n)
      util.add_to_list_of_nested_dict(wseries, p, k, w, n)
      if p == 'b' and k == 10:
        for i in range(3, 10):
          util.add_to_list_of_nested_dict(wseries, p, k, i, n)
  plot_fig(score, 'k', 'Beam width (w)', wseries, save_to=save_base)
  plot_fig(score, 'w', 'Output size (k)', kseries, save_to=save_base)

if __name__ == '__main__':
  make_plots()
