#!/usr/bin/env python
import matplotlib.pyplot as plt
import numpy as np

import util

def plot_fig(graph, score):
  data = np.loadtxt('data/iteration/%s/%s/level-time.txt' % (graph, score))
  data = np.sort(data, axis=0)
  x = data[:, 0]
  y = data[:, 1]
  z = np.polyfit(x, y, 3)
  func = np.poly1d(z)
  x_new = np.linspace(x[0], x[-1], 50)
  y_new = func(x_new)

  fig = plt.figure(figsize=(4, 3.6))
  subfig = fig.add_subplot(111)
  subfig.plot(data[:, 0].astype(int), data[:, 1], 'bo', markersize=10)
  subfig.plot(x_new, y_new, 'g--', linewidth=5)
  subfig.set_xlabel('Level ($|E_P|$)')
  subfig.set_ylabel('Time (sec.)')
  subfig.tick_params()
  fig.tight_layout()
  plt.savefig('../eps/exp/level-time-%s-%s.eps' % (graph, score))
  plt.show()

if __name__ == '__main__':
  score = util.get_arg_or_default(1, 't')
  graph = util.get_arg_or_default(2, 'fifa')
  plot_fig(graph, score)
