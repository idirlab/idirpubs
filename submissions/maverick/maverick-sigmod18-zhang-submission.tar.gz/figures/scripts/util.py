import sys

def get_arg_or_default(idx, default_value):
  val = default_value
  if len(sys.argv) > idx:
    val = sys.argv[idx]
    if val is not None and isinstance(val, type(default_value)):
      val = type(default_value)(val)
  return val

def add_to_list_of_nested_dict(_dict, *keys_and_value):
  value = keys_and_value[-1]
  for key in keys_and_value[:-2]:
    if key not in _dict:
      _dict[key] = {}
    _dict = _dict[key]
  last_key = keys_and_value[-2]
  if last_key not in _dict:
    _dict[last_key] = []
  _dict[last_key].append(value)
