MAIN=$1
MAIN=${MAIN:="main-sigmod"}
latex -src -interaction=nonstopmode $MAIN.tex && \
bibtex $MAIN
latex -src -interaction=nonstopmode $MAIN.tex && \
latex -src -interaction=nonstopmode $MAIN.tex && \
dvips -D 600 -t letter -o $MAIN.ps $MAIN.dvi && \
ps2pdf $MAIN.ps
