#!/usr/bin/env python
import collections
import glob

import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np

import util

def plot_fig(data, chi, nruns, eps_file):
  bins = np.arange(0, 1.1, 0.1)
  plot_conf = (('r', 'Beam-Rdm'), ('o', 'Beam-Opt'),
               ('c', 'Beam-Conv'), ('b', 'Breadth-First'))
  fig, axs = plt.subplots(nrows=4, ncols=1, sharex=True, figsize=(4, 4))
  for row, (key, label) in enumerate(plot_conf):
    subfig = axs[row]
    dist = get_average_bin_counts(np.array(data[key]), bins, 1./nruns)
    cnts, _, _ = subfig.hist(dist, bins=bins, normed=False, rwidth=0.75,
                             fill=False, ec='b', lw=3)
    pos_y = 0.75
    pos_x = 1 if key != 'b' else 4
    subfig.text(bins[pos_x]*1.1, max(cnts)*pos_y, label, fontsize=20)
    subfig.set_ylim(0, max(cnts)*1.15)
    subfig.yaxis.set_major_locator(
        ticker.MaxNLocator(integer=True, nbins='auto'))
    #subfig.spines["top"].set_visible(False)
    #subfig.spines["right"].set_visible(False)

  axs[-1].set_xlabel(r'Exceptionality $\chi_%s$' % chi)
  fig.tight_layout()
  fig.text(0.01, 0.8, '#context-subspace pairs', fontsize=20,
           rotation='vertical')
  fig.subplots_adjust(left=0.21, bottom=0.17, hspace=0.20)
  plt.savefig(eps_file)
  plt.show()

def get_average_bin_counts(data, bins, ratio):
  cnts, _ = np.histogram(data, bins)
  averaged = []
  for i in range(1, len(bins)):
    left = data[data >= bins[i-1]]
    val = left[left < bins[i]]
    averaged.extend(val[:int(round(cnts[i-1] * ratio))])
  return averaged

def make_plot():
  graph = util.get_arg_or_default(1, 'fifa')
  score = util.get_arg_or_default(2, 't')
  nruns = util.get_arg_or_default(3, 10)
  data = collections.defaultdict(list)
  for data_filename in glob.glob('data/%s/*/%s/top-10.txt' % (graph, score)):
    with open(data_filename) as data_file:
      for line in data_file:
        p, b, chi = line.split()
        if int(b) == 10:
          data[p].append(float(chi))
  chi = {'t': 'o', 'f': 'f'}[score]
  eps_file = '../eps/exp/effective-dist-%s-%s.eps' % (graph, score)
  plot_fig(data, chi, nruns, eps_file)

if __name__ == '__main__':
  make_plot()
