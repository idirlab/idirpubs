# coding: utf-8
import numpy as np
import collections
neighbors = ((0, 5), (0, 10), (1, 6), (1, 11), (2, 7), (2, 11), (3, 8), (3, 10), (4, 9), (4, 11), (5, 11), (6, 11), (7, 11), (8, 10), (9, 12))
counter = collections.Counter(x for p in neighbors for x in p)
degrees = [counter[i] for i in range(13)]
am = np.zeros((13, 13))
dm = np.zeros((13, 13))
for i,j in neighbors: am[i,j] = 1
am += am.T
dm[np.diag_indices(13)] = degrees
np.linalg.det(lm[:-1, :-1])
