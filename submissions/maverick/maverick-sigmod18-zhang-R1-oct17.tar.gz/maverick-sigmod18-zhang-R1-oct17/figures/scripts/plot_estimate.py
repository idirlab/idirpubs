#!/usr/bin/env python
# coding: utf-8
import glob
import os.path as path

import matplotlib.pyplot as plt
import numpy as np

import plot_search_error as pse
import util

def plot_ndcg_k(graph, entity, score, beam=10):
  fn_pattern = 'data/%s/%s/%s' % (graph, entity, score)
  est_ndcg_all = []
  noest_ndcg_all = []
  for folder in glob.glob(fn_pattern):
    est_file = '%s/search_scores.c.500.txt' % folder
    noest_file = '%s/search_scores.c.0.txt' % folder
    if not path.exists(est_file) or not path.exists(noest_file):
      continue
    data = pse.load_score_file('%s/search_scores.txt' % folder)
    idcg_k = pse.dcg_k(data['b'][10][1])
    est_data = pse.load_score_file(est_file)
    est_data = np.asarray(tuple(est_data['c'][beam].values()))
    noest_data = pse.load_score_file(noest_file)
    noest_data = np.asarray(tuple(noest_data['c'][beam].values()))
    est_ndcg = [np.asarray(pse.dcg_k(item)) / idcg_k for item in est_data]
    noest_ndcg = [np.asarray(pse.dcg_k(item)) / idcg_k for item in noest_data]
    est_ndcg_all.append(np.average(est_ndcg, axis=0))
    noest_ndcg_all.append(np.average(noest_ndcg, axis=0))
  plt.figure(figsize=(4.3, 3.6))
  x = range(1, 11)
  plt.errorbar(x, np.average(est_ndcg_all, axis=0),
               np.std(est_ndcg_all, axis=0), label=r'Beam-Conv w/ $\hat r_x$',
               c='r', marker='o', ecolor='g', elinewidth=1, capsize=4, capthick=1)
  plt.plot(x, np.average(noest_ndcg_all, axis=0), 'bs-', label=r'Beam-Conv')
  plt.ylabel('NDCG@K')
  plt.xlabel('K')
  util.set_int_tickers(plt.gca().xaxis, nbins=5)
  util.legend_at_top(box_loc=(-0.3, 1.07), ncol=2, left=0.19, top=0.9)
  plt.savefig('../eps/exp/%s-estimate-ndcg.eps' % graph)
  plt.show()

def plot_time(graph, entity, score):
  fn_pattern = 'data/%s/%s/%s' % (graph, entity, score)
  est_times = []
  noest_times = []
  for folder in glob.glob(fn_pattern):
    est_file = '%s/search_time.c.500.txt' % folder
    noest_file = '%s/search_time.c.0.txt' % folder
    if not path.exists(est_file) or not path.exists(noest_file):
      continue
    est_data = pse.load_time_file(est_file)
    est_time = [np.average(est_data['c'][beam]) for beam in range(3, 11)]
    noest_data = pse.load_time_file(noest_file)
    noest_time = [np.average(noest_data['c'][beam]) for beam in range(3, 11)]
    est_times.append(est_time)
    noest_times.append(noest_time)
  est_avg = np.average(est_times, axis=0)
  noest_avg = np.average(noest_times, axis=0)
  plt.figure(figsize=(4.3, 3.6))
  plt.plot(range(3, 11), noest_avg, 'bs-', label=r'Beam-Conv')
  plt.plot(range(3, 11), est_avg, 'ro-', label=r'Beam-Conv w/ $\hat r_x$')
  plt.xlabel('Beam width (w)')
  plt.ylabel('Time (sec.)')
  util.set_int_tickers(plt.gca().xaxis, nbins=5)
  util.legend_at_top(box_loc=(-0.3, 1.07), ncol=2, left=0.19, top=0.9)
  plt.savefig('../eps/exp/%s-estimate-time.eps' % graph)
  plt.show()

def plot():
  graph = util.get_arg_or_default(1, 'fifa')
  entity = util.get_arg_or_default(2, '*')
  score = util.get_arg_or_default(3, 't')
  plot_ndcg_k(graph, entity, score)
  plot_time(graph, entity, score)

if __name__ == '__main__':
  plot()
