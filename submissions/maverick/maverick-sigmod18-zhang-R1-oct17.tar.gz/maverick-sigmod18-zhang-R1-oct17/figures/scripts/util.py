import sys

import matplotlib.pyplot as plt
import matplotlib.ticker as ticker

def get_arg_or_default(idx, default_value, args=tuple(sys.argv)):
  val = default_value
  if len(args) > idx:
    val = args[idx]
    if val is not None and not isinstance(val, type(default_value)):
      val = type(default_value)(val)
  return val

def add_to_list_of_nested_dict(_dict, *keys_and_value):
  value = keys_and_value[-1]
  for key in keys_and_value[:-2]:
    if key not in _dict:
      _dict[key] = {}
    _dict = _dict[key]
  last_key = keys_and_value[-2]
  if last_key not in _dict:
    _dict[last_key] = []
  _dict[last_key].append(value)

def set_int_tickers(axis, **kwargs):
  axis.set_major_locator(ticker.MaxNLocator(integer=True, **kwargs))

def legend_at_top(fig=None, box_loc=None, ncol=2, **kwargs):
  if fig is None:
    fig = plt
  if box_loc is None:
    box_loc = (-0.25, 1.15)
  fig.legend(bbox_to_anchor=box_loc, loc="center left",
             columnspacing=0.2, ncol=ncol, fontsize=18,
             frameon=False).draggable()
  fig.tight_layout(pad=1.01)

  kwargs['top'] = kwargs.get('top', 0.8)
  kwargs['bottom'] = kwargs.get('bottom', 0.17)
  fig.subplots_adjust(**kwargs)
 