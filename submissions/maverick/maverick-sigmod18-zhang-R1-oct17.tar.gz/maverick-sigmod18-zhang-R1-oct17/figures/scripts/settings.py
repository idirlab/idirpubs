#!/usr/bin/env python

# fig.set_xlabel(**xylabel)
# fig.set_ylabel(**xylabel)
xylabel = { # pylint: disable=C0103
    'fontsize': 20
}

# fig.tick_params(**xytick)
xytick = { # pylint: disable=C0103
    'axis'       :'both',
    'which'      :'major',
    'labelsize'  :16,
}

legend = { # pylint: disable=C0103
    'fontsize'       :20,
    'handletextpad'  :0,
    'markerscale'    :1,
    'numpoints'      :1,
    'scatterpoints'  :1,
}

title = { # pylint: disable=C0103
    'fontsize'       :20,
}

subtitle = { # pylint: disable=C0103
    'fontsize'       :16,
}
