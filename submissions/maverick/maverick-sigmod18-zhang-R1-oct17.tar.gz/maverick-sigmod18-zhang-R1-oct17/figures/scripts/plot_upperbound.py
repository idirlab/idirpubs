#!/usr/bin/env python
import matplotlib.pyplot as plt
import numpy as np

import util

def plot_num(entity, chi, graph):
  path_tmpl = 'data/%s/upperbound/%s/%d.{0}.txt' % (graph, chi, entity)
  data_wo_upper = np.loadtxt(path_tmpl.format('ns'))
  data_w_upper = np.loadtxt(path_tmpl.format('ps'))
  x = sorted(set(data_wo_upper[:, 0]) | set(data_w_upper[:, 0]))
  ywo_sub = [data_wo_upper[:, 1][data_wo_upper[:, 0] == xi].mean() for xi in x]
  yw_sub = [data_w_upper[:, 1][data_w_upper[:, 0] == xi].mean() for xi in x]
  ywo_time = []
  yw_time = []
  for xi in x:
    for d, y in ((data_wo_upper, ywo_time), (data_w_upper, yw_time)):
      y_time = d[:, 2][d[:, 0] == xi]
      fy_time = y_time[abs(y_time - np.median(y_time)) < 1 * np.std(y_time)]
      yl = len(y_time)
      # remove outliers
      while len(fy_time) < yl:
        yl = len(fy_time)
        fy_time = fy_time[abs(fy_time - np.mean(fy_time)) < 2 * np.std(fy_time)]
      y.append(fy_time.mean())

  fig, axs = plt.subplots(nrows=1, ncols=2, figsize=(8, 4))
  for i, ylabel, ywo, yw in ((0, 'Execution time (sec.)', ywo_time, yw_time),
                             (1, '#subspaces visited', ywo_sub, yw_sub)):
    subfig = axs[i]
    subfig.plot(x, ywo, 'bo-', label='w/o upper bound', markevery=2)
    subfig.plot(x, yw, 'rs-', label='w/ upper bound', markevery=2)

    subfig.set_xlabel('Output size k')
    subfig.set_ylabel(ylabel)
    #subfig.legend(loc=(0.02, 0.55) if i == 1 else (0.075, 0.02))
    #subfig.legend(loc=(0.02, 0.55))
    subfig.legend(loc='best')

  axs[-1].yaxis.tick_right()
  axs[-1].yaxis.set_label_position("right")

  fig.tight_layout()
  plt.savefig('../eps/exp/upperbound-%s-%s-%s.eps' % (graph, chi, entity))
  plt.show()

def make_plots():
  entity = util.get_arg_or_default(1, 903)
  score = util.get_arg_or_default(2, 't')
  graph = util.get_arg_or_default(3, 'fifa')
  plot_num(entity, score, graph)

if __name__ == '__main__':
  make_plots()
