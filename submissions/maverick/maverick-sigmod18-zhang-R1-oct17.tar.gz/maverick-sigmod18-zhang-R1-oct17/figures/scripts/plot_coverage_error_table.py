#!/usr/bin/env python
import glob

import numpy as np

import util

def plot_table(data):
  beams = set(beam for entity in data for beam in data[entity])
  ylst = []
  for beam in sorted(beams):
    entity_ranks = []
    for entity in data:
      ranks = []
      for method in ('r', 'o', 'c', 'b'):
        if beam < 10 and method == 'b':
          beam_data = np.array(data[entity][10][method])
        else:
          beam_data = np.array(data[entity][beam][method])
        ranks.append(np.average(beam_data[:, 0]))
      entity_ranks.append(ranks)
    ylst.append([beam] + list(zip(np.average(entity_ranks, axis=0),
                                  np.median(entity_ranks, axis=0))))
  formatter = lambda x: (['%.1f/%.1f', '%2d'][isinstance(x, int)] % x).center(17)
  print(' \\\\ \\hline\n'.join(map(lambda a: ' & '.join(map(formatter, a)),
                                   ylst)))

def load_data(data_file_pattern):
  data = {}
  for entity, data_file in enumerate(glob.glob(data_file_pattern)):
    with open(data_file) as dfile:
      for line in dfile:
        field = line.split()
        if len(field) > 4:
          method, beam, _, score, rank = line.split()
        else:
          method, beam, score, rank = line.split()
        beam, rank = map(int, (beam, rank))
        util.add_to_list_of_nested_dict(data, entity, beam, method,
                                        (rank, float(score)))
  return data

def make_table():
  graph = util.get_arg_or_default(1, 'fifa')
  score = util.get_arg_or_default(2, 't')
  data_file_pattern = util.get_arg_or_default(
      3, 'data/%s/*/%s/top-10.rank.txt' % (graph, score))
  all_entity_data = load_data(data_file_pattern)
  plot_table(all_entity_data)

if __name__ == '__main__':
  make_table()
