#!/usr/bin/env python
# coding: utf-8
import glob
import math
import os.path as path

import matplotlib.pyplot as plt
import numpy as np

import util

styles = {'r': 'ro-', 'c': 'bs-.', 'o': 'g*:', 'b': 'k^-.', 'ce': 'mv--'}
labels = {'r': 'Beam-Rdm', 'c': 'Beam-Conv', 'o': 'Beam-Opt',
          'b': 'Breadth-First', 'ce': 'Beam-Conv-Est'}

def dcg(lst):
  return sum(s/math.log2(i+2) for i,s in enumerate(sorted(lst, reverse=True)))

def dcg_k(lst):
  dcg_k = [0]
  for i, s in enumerate(sorted(lst, reverse=True)):
    dcg_k.append(dcg_k[i] + s / math.log2(i+2))
  return dcg_k[1:]

def load_score_file(fn):
  data = {}
  with open(fn) as f:
    for line in f:
      p,b,i,s = line.split()
      util.add_to_list_of_nested_dict(data, p, int(b), int(i), float(s))
  return data

def load_time_file(fn):
  data = {}
  with open(fn) as f:
    for line in f:
      p,b,t = line.split()
      util.add_to_list_of_nested_dict(data, p, int(b), float(t))
  return data

def avg_ndcg(data):
  avg_ndcg = {}
  idcg = dcg(data['b'][10][1])
  for p in ('c', 'r', 'o'):
    avg_ndcg[p] = []
    for b in range(3, 11):
      dcgs = [dcg(data[p][b][i]) for i in data[p].get(b, [])]
      avg = sum(dcgs)/(len(dcgs) if dcgs else 1)/idcg
      avg_ndcg[p].append(avg)
  return avg_ndcg

def avg_ndcg_k(data, b=10):
  avg_ndcg = {}
  idcg = dcg_k(data['b'][b][1])
  for p in ('c', 'r', 'o'):
    avg_ndcg[p] = []
    dcgs = [dcg_k(data[p][b][i]) for i in data[p][b]]
    avg = np.average(dcgs, axis=0) / idcg
    avg_ndcg[p] = avg
  return avg_ndcg

def plot_ndcg_k(graph, entity, score):
  fn_pattern = 'data/%s/%s/%s/search_scores.txt' % (graph, entity, score)
  ndcg_lst = {'r':[], 'o': [], 'c':[]}
  for fn in glob.glob(fn_pattern):
    data = load_score_file(fn)
    c_file = '%s/search_scores.c.0.txt' % path.dirname(fn)
    if path.exists(c_file):
      c_data = load_score_file(c_file)
      data['c'] = c_data['c']
    ndcg = avg_ndcg_k(data)
    for p in ndcg:
      ndcg_lst[p].append(ndcg[p])
  plt.figure(figsize=(4, 3.6))
  x = range(1, 11)
  for p in ndcg_lst:
    plt.plot(x, np.average(ndcg_lst[p], axis=0), styles[p], label=labels[p])
  plt.ylabel('NDCG@K')
  plt.xlabel('K')
  util.set_int_tickers(plt.gca().xaxis, min_n_ticks=8)
  util.legend_at_top(left=0.2)
  plt.savefig('../eps/exp/%s-ndcg-k.eps' % graph)
  plt.show()

def plot_ndcg(graph, entity, score):
  fn_pattern = 'data/%s/%s/%s/search_scores.txt' % (graph, entity, score)
  ndcg_lst = {'r':[], 'o': [], 'c':[]}
  for fn in glob.glob(fn_pattern):
    data = load_score_file(fn)
    c_file = '%s/search_scores.c.0.txt' % path.dirname(fn)
    if path.exists(c_file):
      c_data = load_score_file(c_file)
      data['c'] = c_data['c']
    ndcg = avg_ndcg(data)
    for p in ndcg:
      ndcg_lst[p].append(ndcg[p])
  plt.figure(figsize=(4, 3.6))
  x = range(3, 11)
  for p in ndcg_lst:
    plt.plot(x, np.average(ndcg_lst[p], axis=0), styles[p], label=labels[p])
  plt.ylabel('NDCG@10')
  plt.xlabel('Beam width (w)')
  util.set_int_tickers(plt.gca().xaxis, min_n_ticks=8)
  util.legend_at_top()
  plt.savefig('../eps/exp/%s-ndcg.eps' % graph)
  plt.show()

def plot_time(graph, entity, score):
  fn_pattern = 'data/%s/%s/%s/search_time.txt' % (graph, entity, score)
  time_lst = {'r':[], 'o': [], 'c': [], 'b': []}
  for fn in glob.glob(fn_pattern):
    data = load_time_file(fn)
    c_file = '%s/search_time.c.0.txt' % path.dirname(fn)
    if path.exists(c_file):
      c_data = load_time_file(c_file)
      data['c'] = c_data['c']
    for p in time_lst:
      brange = [10] if p == 'b' else range(3, 11)
      time_lst[p].append([np.average(data[p][b]) for b in brange])
  plt.figure(figsize=(4, 3.6))
  x = range(3, 11)
  for p in time_lst:
    avg = np.average(time_lst[p], axis=0)
    if p == 'b':
      avg = list(avg) * 8
    plt.plot(x, avg, styles[p], label=labels[p])
  plt.ylabel('Time (sec.)')
  plt.xlabel('Beam width')
  util.set_int_tickers(plt.gca().xaxis, min_n_ticks=8)
  max_tick = plt.gca().yaxis.get_majorticklocs()[-1]
  box_loc = [-0.25, 1.15]
  if max_tick > 1000:
    box_loc[0] = -0.35
  elif max_tick > 100:
    box_loc[0] = -0.3
  util.legend_at_top(box_loc=box_loc)
  plt.savefig('../eps/exp/%s-search-time.eps' % graph)
  plt.show()

def plot():
  graph = util.get_arg_or_default(1, 'fifa')
  entity = util.get_arg_or_default(2, '*')
  score = util.get_arg_or_default(3, 't')
  plot_ndcg(graph, entity, score)
  plot_ndcg_k(graph, entity, score)
  plot_time(graph, entity, score)

if __name__ == '__main__':
  plot()
