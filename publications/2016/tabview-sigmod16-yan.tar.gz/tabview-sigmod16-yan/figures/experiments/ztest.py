import math


domains = ["books", "film", "music", "TV", "people"]
methods = ["Concise", "Tight", "Diverse", "Freebase", "Experts", "YPS09", "Graph"]
constant_sizes={"Concise":52, "Tight":48, "Diverse":52, "Freebase":44, "Experts":48, "YPS09":52, "Graph":40}
sizes = {}
rates = {}
zscores = {}

for domain in domains:
	sizes[domain]={}
	rates[domain]={}
	for method in methods:
		sizes[domain][method]=constant_sizes[method]
		
sizes["film"]["Diverse"]=51
sizes["TV"]["Diverse"]=48
sizes["people"]["Diverse"]=48

rates["books"]["Concise"]= 0.730 
rates["film"]["Concise"]= 0.865 
rates["music"]["Concise"]= 0.903 
rates["TV"]["Concise"]= 0.884
rates["people"]["Concise"]= 0.788

rates["books"]["Tight"]= 0.687 
rates["film"]["Tight"]= 0.854 
rates["music"]["Tight"]= 0.979 
rates["TV"]["Tight"]= 0.875 
rates["people"]["Tight"]= 0.666

rates["books"]["Diverse"]= 0.846 
rates["film"]["Diverse"]= 0.921 
rates["music"]["Diverse"]= 0.730 
rates["TV"]["Diverse"]= 0.75 
rates["people"]["Diverse"]= 0.875

rates["books"]["Freebase"]= 0.818 
rates["film"]["Freebase"]= 0.954 
rates["music"]["Freebase"]= 0.931 
rates["TV"]["Freebase"]= 0.909 
rates["people"]["Freebase"]= 0.681

rates["books"]["Experts"]= 0.604 
rates["film"]["Experts"]= 0.833 
rates["music"]["Experts"]= 0.895 
rates["TV"]["Experts"]= 0.812 
rates["people"]["Experts"]= 0.687

rates["books"]["YPS09"]= 0.692 
rates["film"]["YPS09"]= 0.884 
rates["music"]["YPS09"]= 0.923 
rates["TV"]["YPS09"]= 0.692 
rates["people"]["YPS09"]= 0.634

rates["books"]["Graph"]= 0.975 
rates["film"]["Graph"]= 0.875 
rates["music"]["Graph"]= 0.875 
rates["TV"]["Graph"]= 0.9 
rates["people"]["Graph"]= 0.85

for domain in domains:
	zscores[domain]={}
	for i in range(1,7):
		m1 = methods[i]
		zscores[domain][m1]={}
		n1 = sizes[domain][m1]
		p1 = rates[domain][m1]
		for j in range(0,i):
			m2 = methods[j]
			n2 = sizes[domain][m2]
			p2 = rates[domain][m2]
			
			p = (n1*p1+n2*p2)/(n1+n2)
			s = math.sqrt(p*(1-p)*(1/n1+1/n2))
			z = (p1-p2)/s
			
			zscores[domain][m1][m2]=z	
			
for domain in domains:
	print(domain)
	print("---------------------------")
	print("       ", end="")
	for i in range(1,7):
		print("      ", end="")
		print(methods[i], end="")
	print()
	for j in range(0,6):
		m2 = methods[j]
		print(m2, end="")
		for i in range(1,j+1):		
			print("            ", end="")
		for i in range(j+1,7):
			m1 = methods[i]
			print("       ", end="")
			print("%.2f" % zscores[domain][m1][m2], end="")
		print()
	print("---------------------------")
