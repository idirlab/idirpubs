#!/usr/bin/env python
# coding: utf-8
import glob
import math
import os.path as path

import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import numpy as np

from plot_search_error import load_time_file
from plot_search_error import load_score_file
import util

styles = {'r': 'ro-', 'c': 'bs-.', 'o': 'g*:', 'b': 'k^-.', 'o.a': 'mv--', 'c.a': 'cd:'}
labels = {'r': 'Beam-Rdm', 'c': 'Beam-Conv', 'o': 'Beam-Opt',
          'b': 'Breadth-First', 'c.a': 'A*-Conv', 'o.a': 'A*-Opt'}

def plot_time(score):
  graphs = (100, 200, 500, 1000, 2000)
  #graphs = (100, 200, 500)
  graph_sizes = (14195, 24572, 60659, 116720, 215895)
  plist = ('b', 'c', 'o', 'r', 'o.a', 'c.a')
  graph_time = {p: [] for p in plist}
  ignored_p = set()
  for graph in graphs:
    fn_pattern = 'data/%s/*/%s/search_time.*.0.txt' % (graph, score)
    time_lst = {'r':[], 'o': [], 'c': [], 'b': [], 'c.a': [], 'o.a': []}
    for fn in glob.glob(fn_pattern):
      data = load_time_file(fn)
      fn_parts = path.basename(fn).split('.')
      key = p = fn_parts[1]
      if len(fn_parts) > 4:
        key = '.'.join(fn_parts[1:3])
      if key not in plist:
        ignored_p.add(key)
        continue
      elif p not in data:
        print('missing', p, 'in', fn)
      elif -1 in data[p]:
        data[p][10] = data[p][-1]
      elif 10 not in data[p]:
        print('no', p, 10, 'in file', fn)
        continue
      #time_lst[key].append(np.average(data[p][10]))
      time_lst[key].append(np.mean(data[p][10]))
    for p, p_times in time_lst.items():
      #graph_time[p].append(np.average(p_times))
      graph_time[p].append(np.mean(p_times))
  print('ignored p:', ignored_p)
  plt.figure(figsize=(5, 4))
  x = graph_sizes[:len(graphs)]
  for p in graph_time:
    plt.plot(x, graph_time[p], styles[p], label=labels[p])
  plt.ylabel('Time (sec.)')
  plt.xlabel('|V(G)|')
  #plt.semilogx()
  #plt.semilogy()
  #plt.xticks(rotation=30)
  plt.ticklabel_format(style='sci', axis='x', scilimits=(0, 0), useOffset=True)
  util.set_int_tickers(plt.gca().xaxis, min_n_ticks=5)
  #max_tick = plt.gca().yaxis.get_majorticklocs()[-1]
  box_loc = [-0.15, 1.27]
  util.legend_at_top(box_loc=box_loc, bottom=0.15, top=0.71)
  plt.savefig('../eps/exp/benchmark-time.eps')
  plt.show()

def plot_top_scores(score):
  #graphs = (100, 200, 500, 1000, 2000)
  graphs = (1000, )
  plist = ('b', 'c', 'o', 'r', 'o.a', 'c.a')
  graph_scores = {p: [] for p in plist}
  ignored_p = set()
  for graph in graphs:
    fn_pattern = 'data/%s/*/%s/search_scores.*.0.txt' % (graph, score)
    score_list = {'r':[], 'o': [], 'c': [], 'b': [], 'c.a': [], 'o.a': []}
    for fn in glob.glob(fn_pattern):
      data = load_score_file(fn)
      fn_parts = path.basename(fn).split('.')
      key = p = fn_parts[1]
      if len(fn_parts) > 4:
        key = '.'.join(fn_parts[1:3])
      if key not in plist:
        ignored_p.add(key)
        continue
      elif p not in data:
        print('missing', p, 'in', fn)
      elif -1 in data[p]:
        data[p][10] = data[p][-1]
      elif 10 not in data[p]:
        print('no', p, 10, 'in file', fn)
        continue
      for values in data[p][10].values():
        score_list[key].extend(values)
    for p, p_scores in score_list.items():
      graph_scores[p].extend(p_scores)
  print('ignored p:', ignored_p)
  fig, axs = plt.subplots(nrows=len(graph_scores), ncols=1, sharex=True, figsize=(6, 6))
  bins = np.arange(0, 1.1, 0.1)
  for row, p in enumerate(graph_scores):
    print(len(graph_scores[p]))
    subfig = axs[row]
    subfig.hist(graph_scores[p], bins=bins, normed=False, rwidth=0.75,
                fill=False, ec='b', lw=3)
    subfig.set_title(labels[p])
  plt.tight_layout(h_pad=0.93)
  plt.savefig('../eps/exp/benchmark-scores.eps')
  plt.show()


def plot():
  score = util.get_arg_or_default(1, 't')
  plot_time(score)
  plot_top_scores(score)

if __name__ == '__main__':
  plot()
