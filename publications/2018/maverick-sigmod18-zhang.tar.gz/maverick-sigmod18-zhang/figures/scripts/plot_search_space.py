#!/usr/bin/env python
import os.path as path

import matplotlib.pyplot as plt
import numpy as np

import util

def make_plots():
  graph = util.get_arg_or_default(1, 'dummy')
  entity = util.get_arg_or_default(2, 0)

  file_pattern = 'data/%s/%d/n/{}.txt' % (graph, entity)
  minus_file = file_pattern.format('p-minus')

  show_minus = util.get_arg_or_default(3, True) and path.exists(minus_file)

  p_plus = np.loadtxt(file_pattern.format('p-plus'), dtype=int)
  p = np.loadtxt(file_pattern.format('p'), dtype=int)
  plt.figure(figsize=(4, 3.6))
  plt.plot(p_plus[:, 0], p_plus[:, 1],
           'rv-', label=r'$\mathbb{P}^+$', markersize=10)
  if show_minus:
    p_minus = np.loadtxt(minus_file, dtype=int)
    plt.bar(p_minus[:, 0], p_minus[:, 1], label=r'$\mathbb{P}^-$', log=True)
    plt.bar(p[:, 0], p[:, 1] - p_minus[:, 1], label=r'$\mathbb{P}$',
            bottom=p_minus[:, 1])
    plt.bar(p_plus[:, 0], p_plus[:, 1] - p[:, 1], bottom=p[:, 1])
    plt.legend(loc=(0.005, 0.50), frameon=False).draggable()
  else:
    plt.bar(p[:, 0], p[:, 1], label=r'$\mathbb{P}$', log=True)
    plt.bar(p_plus[:, 0], p_plus[:, 1] - p[:, 1], bottom=p[:, 1])
    plt.legend(loc=(0.005, 0.60), frameon=False).draggable()
  plt.ylabel('The size of space')
  plt.xlabel('Level ($|E_P|$)')
  util.set_int_tickers(plt.gca().xaxis, min_n_ticks=4)
  plt.tight_layout()
  plt.subplots_adjust(left=0.20, bottom=0.19)
  if show_minus:
    plt.savefig('../eps/exp/%s-search-space-min.eps' % graph)
  else:
    plt.savefig('../eps/exp/%s-search-space.eps' % graph)
  plt.show()


if __name__ == '__main__':
  make_plots()
