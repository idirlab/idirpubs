#!/usr/bin/env python
import collections
import glob

import matplotlib.pyplot as plt
import numpy as np

import util

def plot_level_count(data, save_to):
  bars = []
  max_levels = 0
  for idx, label, hatch, in (
      ('r', 'Beam-Rdm', '/'), ('o', 'Beam-Opt', 'o'),
      ('c', 'Beam-Conv', '.'), ('b', 'Breadth-First', '*')):
    level_counts = [np.mean(cnts) for _, cnts in sorted(data[idx].items())]
    max_levels = max(max_levels, len(level_counts))
    bars.append((level_counts, label, hatch, idx))
  bar_width = 0.75
  index = np.arange(max_levels)
  fig, axs = plt.subplots(nrows=4, ncols=1, sharex=True, figsize=(3, 4.8))
  for row, (y, label, hatch, idx) in enumerate(bars):
    subfig = axs[row]
    subfig.bar(index[:len(y)], y, bar_width, label=label, fill=False,
               edgecolor='b', linewidth=2)
    if idx != 'b':
      subfig.set_ylim(0, 11)
    subfig.set_title(label)

  axs[-1].set_xlabel('Level ($|E_P|$)')
  fig.tight_layout()
  fig.text(0.01, 0.8, '#patterns evaluated', fontsize=20, rotation='vertical')
  fig.subplots_adjust(left=0.22, right=0.95, bottom=0.14, hspace=0.60)
  plt.savefig('%s.eps' % save_to)
  plt.show()

def plot_context_size(data, save_to):
  fig, axs = plt.subplots(nrows=4, ncols=1, sharex=True, figsize=(3, 4.8))
  row = 0
  for idx, label, _, in (
      ('r', 'Beam-Rdm', 'r*'), ('o', 'Beam-Opt', 'go'),
      ('c', 'Beam-Conv', 'k^'), ('b', 'Breadth-First', 'bs')):
    counts = []
    for size, count in data[idx].items():
      counts.extend([size] * round(count))
    subfig = axs[row]
    row += 1
    max_size = max(data[idx].keys())
    subfig.hist(counts, bins=np.logspace(1, np.log10(max_size), 10),
                normed=False, color='c', rwidth=0.75, fill=False, ec='b', lw=2)
    subfig.set_title(label)
    subfig.set_xscale('log')
  axs[-1].set_xlabel('Context size ($|C|$)')
  fig.tight_layout()
  fig.text(0.01, 0.8, '#patterns evaluated', fontsize=20, rotation='vertical')
  fig.subplots_adjust(left=0.22, right=0.95, bottom=0.15, hspace=0.60)
  plt.savefig('%s.eps' % save_to)
  plt.show()

def load_sizes(size_file_pattern, rounds):
  data = collections.defaultdict(collections.Counter)
  data_files = glob.glob(size_file_pattern)
  avg_factor = rounds * len(data_files)
  for filename in data_files:
    with open(filename) as size_file:
      for line in size_file:
        method, size = line.split()
        data[method][int(size)] += 1./avg_factor
  return data

def load_counts(count_file_pattern, rounds):
  data = collections.defaultdict(collections.Counter)
  data_files = glob.glob(count_file_pattern)
  avg_factor = rounds * len(data_files)
  for filename in data_files:
    with open(filename) as count_file:
      for line in count_file:
        row = line.split()
        method = row[0]
        k, beam, level, count = map(int, row[1:])
        if k == 10 and beam == 10:
          data[method][level] += float(count)/avg_factor
  return data

def make_plot():
  graph = util.get_arg_or_default(1, 'fifa')
  score = util.get_arg_or_default(2, 't')
  entity = util.get_arg_or_default(3, -1)
  rounds = util.get_arg_or_default(4, 10)

  count_eps = '../eps/exp/level-count-%s-%s{0}' % (graph, score)
  size_eps = '../eps/exp/context-size-%s-%s{0}' % (graph, score)
  if entity == -1:
    count_file_pattern = 'data/%s/*/%s/num_pattern.txt' % (graph, score)
    size_file_pattern = 'data/%s/*/%s/context_size.txt' % (graph, score)
    count_eps = count_eps.format('')
    size_eps = size_eps.format('')
  else:
    count_file_pattern = 'data/%s/%d/%s/num_pattern.txt' % (
        graph, entity, score)
    size_file_pattern = 'data/%s/%d/%s/context_size.txt' % (
        graph, entity, score)
    count_eps = count_eps.format('-%d' % entity)
    size_eps = size_eps.format('-%d' % entity)
  counts = load_counts(count_file_pattern, rounds)
  sizes = load_sizes(size_file_pattern, rounds)
  plot_level_count(counts, count_eps)
  plot_context_size(sizes, size_eps)

if __name__ == '__main__':
  make_plot()
