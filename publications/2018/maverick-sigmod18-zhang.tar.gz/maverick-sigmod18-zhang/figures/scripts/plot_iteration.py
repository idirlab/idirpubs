#!/usr/bin/env python
import glob

import matplotlib.pyplot as plt
import numpy as np
import util

def plot_fig(variable, xlabel, series, save_to):
  styles = {'r': 'ro-', 'c': 'bs-.', 'o': 'g*:', 'b': 'k^-.'}
  labels = {'r': 'Beam-Rdm', 'c': 'Beam-Conv', 'o': 'Beam-Opt',
            'b': 'Breadth-First'}

  fig = plt.figure(figsize=(4, 4))
  subfig = fig.add_subplot(111)
  for p in ('r', 'o', 'c', 'b'):
    if p not in series or 10 not in series[p]:
      continue
    data = series[p][10]
    x = sorted(data.keys())
    y = [np.mean(data[xi]) for xi in x]
    #if p == 'r':
    z = np.polyfit(x, y, 1)
    func = np.poly1d(z)
    x = np.linspace(x[0], x[-1], len(x))
    y = func(x)
    subfig.plot(x, y, styles[p], label=labels[p], markersize=15)
  subfig.semilogy()

  subfig.set_ylabel('#patterns evaluated')
  subfig.set_xlabel(xlabel)
  util.set_int_tickers(subfig.xaxis, min_n_ticks=8)
  util.legend_at_top(box_loc=(-0.3, 1.15))
  plt.savefig('%s-%s.eps' % (save_to, variable))
  plt.show()

def load_data(data_filename, kseries, wseries):
  with open(data_filename) as data_file:
    for line in data_file:
      cols = line.split()
      k, w, n = map(int, cols[1:])
      p = cols[0]
      util.add_to_list_of_nested_dict(kseries, p, w, k, n)
      util.add_to_list_of_nested_dict(wseries, p, k, w, n)
      if p == 'b' and k == 10:
        for i in range(3, 10):
          util.add_to_list_of_nested_dict(wseries, p, k, i, n)

def make_plots():
  graph = util.get_arg_or_default(1, 'fifa')
  score = util.get_arg_or_default(2, 't')
  entity = util.get_arg_or_default(3, -1)
  kseries, wseries = {}, {}
  if entity == -1:
    save_base = '../eps/exp/iter-%s-%s' % (graph, score)
    for data_filename in glob.glob('data/%s/*/%s/num_pattern_total.txt' % (
        graph, score)):
      load_data(data_filename, kseries, wseries)
  else:
    save_base = '../eps/exp/iter-%s-%s-%s' % (graph, score, entity)
    data_filename = 'data/%s/%d/%s/num_pattern_total.txt' % (
        graph, entity, score)
    load_data(data_filename, kseries, wseries)
  plot_fig('k', 'Beam width (w)', wseries, save_to=save_base)
  plot_fig('w', 'Output size (k)', kseries, save_to=save_base)

if __name__ == '__main__':
  make_plots()
